#!/bin/bash

process_line() {
    local line="$1"
    local output=""

    for word in $line; do
        if [[ "$word" =~ ^[0-9]+$ ]]; then 
            output+="$word (Digits) "
        elif [[ "$word" =~ ^[a-zA-Z]+$ ]]; then
            output+="$word (Word-English/Roman) "
        elif [[ "$word" =~ ^[[:punct:]]+$ ]]; then
            output+="$word (Symbol) "
        elif [[ "$word" =~ ^[अ-जडण-शष-ह़ऽ-ॅॉ़ऽं-ऽॐ-ॡ]+$ ]]; then
            output+="$word (Devnagri/Konkani/Marathi) "
        elif [[ "$word" =~ ^[0-9]{2}/[0-9]{2}/[0-9]{4}$ ]]; then
            output+="$word (DD/MM/YYYY) "
        elif [[ "$word" =~ ^[0-9]{4}/[0-9]{2}/[0-9]{2}$ ]]; then
            output+="$word (YYYY/MM/DD) "
        elif [[ "$word" =~ ^[[:alnum:]]+$ ]]; then
            output+="$word (Special Symbol) "
        else
            output+="$word (others) "
        fi
    done

    echo "$output" >> OutputA.txt
}

export -f process_line
export -p

# Clear the output file
> OutputA.txt

# Read file line by line and process in parallel
while IFS= read -r line; do
    process_line "$line" &
    # Limit the number of concurrent processes to prevent overwhelming the system
    if [[ $(jobs -r -p | wc -l) -ge 4 ]]; then
        wait -n
    fi
done < Input.txt

# Wait for all background processes to finish
wait

